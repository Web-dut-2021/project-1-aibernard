#MJX
He is a god.
The strongest of them!!!