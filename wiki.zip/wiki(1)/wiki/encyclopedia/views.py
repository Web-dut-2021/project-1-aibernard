from django.shortcuts import render
import random
from . import util, urls

import markdown2

def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })

def show(request, name):
    try:
        return render(request, "encyclopedia/target.html", {
        "entries": markdown2.markdown(util.get_entry(name)),
        "name":name
        })
    except:
        return render(request, "encyclopedia/no_match.html")

def search(request):
    search_word = request.GET.get('wd', '').lower()
    try:
        return render(request, "encyclopedia/target.html", {
            "entries":markdown2.markdown(util.get_entry(search_word)),
            "name":search_word
        })
    except:
        list1 = util.list_entries()
        list2 = []
        for li in list1:
            if search_word in li.lower():
                list2.append(li)
        try:
            return render(request, "encyclopedia/index.html", {
                "entries": list2
            })
        except:
            return render(request, "encyclopedia/no_match.html")


def no_match(request):
    return render(request, "encyclopedia/no_match.html")

def create_newpage(request):
    return render(request, "encyclopedia/create_newpage.html")

def create(request):
    list1=util.list_entries()
    print(list1)
    title_copy = request.GET.get('title', '')
    content_copy = request.GET.get('content', '')
    util.save_entry(title_copy, content_copy)
    if title_copy in list1:
        return render(request, "encyclopedia/faild.html", {
            "entries":markdown2.markdown(util.get_entry(title_copy)),
            "name":title_copy
        })
    return render(request, "encyclopedia/success.html", {
        "entries": markdown2.markdown(util.get_entry(title_copy))
    })

def random_page(request):
    list1 = util.list_entries()
    num = len(list1)
    randomNum = random.randrange(num)-1
    return render(request, "encyclopedia/target.html", {
        "entries": markdown2.markdown(util.get_entry(list1[randomNum])),
        "name":list1[randomNum]
    })

def edit(request, name):
    return render(request, "encyclopedia/edit.html", {
        "name":name,
        "entry":markdown2.markdown(util.get_entry(name))
    })

def change(request, name):
    title_copy = name
    content_copy = request.GET.get('content', '')
    util.save_entry(title_copy, content_copy)
    return render(request, "encyclopedia/success.html", {
        "entries": markdown2.markdown(util.get_entry(title_copy))
    })